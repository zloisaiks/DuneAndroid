package com.example.dune;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setBackgroundColor(Color.rgb(12, 12, 14));
        root.setPadding(dp(16), dp(10), dp(16), dp(10));

        TextView title = new TextView(this);
        title.setText("DUNE  •  THE BATTLE FOR ARRakis".toUpperCase());
        title.setTextColor(Color.rgb(226, 183, 91)); title.setTextSize(20); title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, dp(42)));

        TextView screen = new TextView(this);
        screen.setText("ПОДГОТОВКА ЭМУЛЯТОРА\n\nROM-файл включён в проект.\nСледующий этап — подключить ядро Genesis Plus GX\nчерез LibretroDroid и вывести изображение игры.");
        screen.setTextColor(Color.LTGRAY); screen.setTextSize(16); screen.setGravity(Gravity.CENTER);
        screen.setBackgroundColor(Color.rgb(24, 25, 28));
        LinearLayout.LayoutParams screenParams = new LinearLayout.LayoutParams(-1, 0, 1f);
        screenParams.setMargins(0, dp(8), 0, dp(8)); root.addView(screen, screenParams);

        LinearLayout controls = new LinearLayout(this); controls.setGravity(Gravity.CENTER_VERTICAL); controls.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout pad = new LinearLayout(this); pad.setOrientation(LinearLayout.VERTICAL); pad.setGravity(Gravity.CENTER);
        pad.addView(control("▲"));
        LinearLayout mid = new LinearLayout(this); mid.setGravity(Gravity.CENTER);
        mid.addView(control("◀")); mid.addView(control("●")); mid.addView(control("▶")); pad.addView(mid);
        pad.addView(control("▼"));
        controls.addView(pad, new LinearLayout.LayoutParams(0, -2, 1f));
        LinearLayout buttons = new LinearLayout(this); buttons.setGravity(Gravity.CENTER);
        buttons.addView(control("B")); buttons.addView(control("A")); buttons.addView(control("C"));
        controls.addView(buttons, new LinearLayout.LayoutParams(0, -2, 1f));
        root.addView(controls, new LinearLayout.LayoutParams(-1, dp(150)));
        setContentView(root);
    }

    private Button control(String label) {
        Button b = new Button(this); b.setText(label); b.setTextSize(18); b.setTextColor(Color.WHITE);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(65, 65, 70)));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(58), dp(46)); p.setMargins(dp(3), dp(2), dp(3), dp(2)); b.setLayoutParams(p); return b;
    }
}
